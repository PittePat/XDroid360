# -*- coding: utf-8 -*-
"""Maps abilities to the small icons in icons_data.py (own simple icons, no game graphics; no GUI code)."""
import base64

from icons_data import ICONS

_SCHOOLS = (('Mage - Arcane', 'arcane'), ('Primal - Fire', 'fire'), ('Primal - Earth', 'earth'),
            ('Primal - Cold', 'cold'), ('Primal - Lightning', 'lightning'), ('Creation', 'creation'),
            ('Spirit', 'spirit'), ('Entropy', 'entropy'))
_TREES = {'Warrior - base': 'warrior', 'Warrior - Dual Weapon': 'dual', 'Warrior - Weapon and Shield': 'shield',
          'Warrior - Two-Handed': 'twohand', 'Rogue - Archery': 'archery', 'Rogue - base': 'rogue',
          'Companion - Shale / War Dog': 'companion'}
_IMMUNITIES = {'Cold Immunity': 'imm_cold', 'Fire Immunity': 'imm_fire', 'Nature Immunity': 'imm_nature',
               'Spirit Immunity': 'imm_spirit', 'Lightning Immunity': 'imm_lightning',
               'Critical Hit Immunity': 'imm_crit'}
_SKILLS = {'Coercion': 'coercion', 'Combat Tactics': 'combat_tactics', 'Combat Training': 'combat_training',
           'Herbalism': 'herbalism', 'Lockpicking': 'lockpicking', 'Poison-Making': 'poison_making',
           'Stealing': 'stealing', 'Stealth': 'stealth', 'Survival': 'survival', 'Trap-Making': 'trap_making'}
_RANK_PREFIXES = (('Improved ', 2), ('Expert ', 3), ('Master ', 4))

def icon_key(kind, group, name):
    """Key of the icon for an ability (kind, group and name as in abilities.Row); 'unknown' if there is none."""
    if kind == 'skill':
        rank, base = 1, name
        for prefix, number in _RANK_PREFIXES:
            if name.startswith(prefix):
                rank, base = number, name[len(prefix):]
        slug = _SKILLS.get(base)
        return 'skill_%s_%d' % (slug, rank) if slug else 'unknown'
    if kind == 'trait':
        return _IMMUNITIES.get(name, 'unknown')
    if group.startswith('Specialization - '):
        key = 'spec_' + group[len('Specialization - '):].lower().replace(' ', '_')
        return key if key in ICONS else 'unknown'
    if group in _TREES:
        return _TREES[group]
    for prefix, key in _SCHOOLS:
        if group.startswith(prefix):
            return key
    return 'unknown'

def icon_png(key):
    """The PNG bytes (24x24) of an icon; the 'unknown' icon for an unknown key."""
    return base64.b64decode(ICONS.get(key) or ICONS['unknown'])
